import io
import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
from functools import partial

activation_dict = {
    'GELU': nn.GELU(),
    'ReLU': nn.ReLU(),
    'LeakyReLU': nn.LeakyReLU(),
    'Tanh': nn.Tanh(),
    'SiLU': nn.SiLU(),
    'ELU': nn.ELU(),
    'SELU': nn.SELU(),
    'CELU': nn.CELU(),
    'Softplus': nn.Softplus(),
    'Softsign': nn.Softsign(),
    'Hardshrink': nn.Hardshrink(),
    'Hardtanh': nn.Hardtanh(),
    'Hardsigmoid': nn.Hardsigmoid(),
    'LogSigmoid': nn.LogSigmoid(),
    'Softshrink': nn.Softshrink(),
    'PReLU': nn.PReLU(),
    'Softmin': nn.Softmin(dim=-1),
    'Softmax': nn.Softmax(dim=-1),
    'Softmax2d': nn.Softmax2d(),
    'LogSoftmax': nn.LogSoftmax(dim=-1),
    'Sigmoid': nn.Sigmoid(),
    'Identity': nn.Identity(),
    'Tanhshrink': nn.Tanhshrink(),
    'RReLU': nn.RReLU(),
    'Hardswish': nn.Hardswish(),   
    'Mish': nn.Mish(),
}

optimizers_dict = {
    'AdamW': partial(
        torch.optim.AdamW, 
        betas = (0.9, 0.98),
    ),
    'NAdam': partial(
        torch.optim.NAdam, 
        betas = (0.9, 0.98),
    ),
    'L-AdamW': partial( # large batch AdamW
        torch.optim.AdamW, 
        betas = (0.9, 0.999),
    ),
    'S-AdamW': partial( # small batch AdamW
        torch.optim.AdamW, 
        betas = (0.92, 0.96),
    ),
    'B-AdamW': partial(
        torch.optim.AdamW, 
        betas = (0.95, 0.999),
    ),
    'Adam': partial(
        torch.optim.Adam,
        betas = (0.9, 0.98),
    ),
    'SGD': partial(
        torch.optim.SGD,
        momentum=0.8, 
    ),
    'Adagrad': partial(
        torch.optim.Adagrad,
    ),
    'Adadelta': partial(
        torch.optim.Adadelta,
    ),
    'RMSprop': partial(
        torch.optim.RMSprop,
    ),
    'Adamax': partial(
        torch.optim.Adamax,
    ),
    'Rprop': partial(
        torch.optim.Rprop,
    ),
}

def initialize_weights(model):
    for module in model.modules():
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            init.kaiming_normal_(module.weight)

def params2layerlist(params, layer_num=6):
    params_list = []
    for _ in range(layer_num):
        params_list.append(params) 
    return params_list

def silence_output(func):
    def wrapper(*args, **kwargs):
        original_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            result = func(*args, **kwargs)
        finally:
            sys.stdout = original_stdout
        return result
    return wrapper
    
def t_pearson(X, Y):
    mean_X = torch.mean(X)
    mean_Y = torch.mean(Y)
    cov = torch.mean((X - mean_X) * (Y - mean_Y))
    std_X = torch.std(X)
    std_Y = torch.std(Y)
    pearson = cov / (std_X * std_Y)
    return pearson

class BatchNormNd(nn.Module):
    def __init__(self, num_features):
        super(BatchNormNd, self).__init__()
        self.bn = nn.BatchNorm1d(num_features)

    def forward(self, x):
        shape = x.size()
        x = x.view(-1, shape[-1]) 
        x = self.bn(x)
        x = x.view(*shape)
        return x

class MultiPropDecoder(nn.Module):
    def __init__(self, 
        feature_dim = (1024, 12288),
        hidden_dim = 12288,
        dense_dim = 1024,
        dropout_rate = 0.1, 
        output_dim = 1,
        activation = "SiLU",
        projection_transform = 'Sigmoid',
        linear_projection = False
    ):
        super(MultiPropDecoder, self).__init__()
        self.dense_concentrate = nn.Sequential(
            nn.Dropout(p=dropout_rate),
            nn.Linear(feature_dim[0], hidden_dim, bias=True),
            activation_dict[activation],
            BatchNormNd(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim, bias=True),
        )
        self.scattered_concentrate = nn.Sequential(
            nn.Dropout(p=dropout_rate),
            nn.Linear(feature_dim[1], feature_dim[1], bias=True),
            activation_dict[activation],
            BatchNormNd(feature_dim[1]),
            nn.Linear(feature_dim[1], hidden_dim, bias=True),
        )
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim + feature_dim[0], dense_dim, bias=True),
            BatchNormNd(dense_dim),
            activation_dict[activation],
            nn.Linear(dense_dim, dense_dim, bias=True),
            BatchNormNd(dense_dim),
            activation_dict[activation],
            nn.Linear(dense_dim, dense_dim, bias=True),
            activation_dict[activation],
            nn.Linear(dense_dim, output_dim, bias=True),
            activation_dict[projection_transform],
            nn.Linear(output_dim, output_dim) if linear_projection else nn.Identity(),
        )
        self.dense_concentrate.cuda()
        self.scattered_concentrate.cuda()
        self.projection.cuda()
    
    def forward(self, features, projected_feats):
        concentrate_features = self.dense_concentrate(features) + self.scattered_concentrate(projected_feats)
        return self.projection(
            torch.cat(
                (
                    concentrate_features, 
                    features
                ), dim = -1
            )
        )

class MATRIX_LOSS(nn.Module):
    def __init__(self, weight_power: float = 0.0, eps: float = 1e-8):
        super().__init__()
        self.weight_power = weight_power
        self.eps = eps

    def forward(self, preds: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:

        true_diffs = targets.unsqueeze(1) - targets.unsqueeze(0)
        pred_diffs = preds.unsqueeze(1) - preds.unsqueeze(0)
        mse_loss = (pred_diffs - true_diffs).pow(2)

        weights = true_diffs.abs()
        weights = weights.pow(self.weight_power) + self.eps
        weighted_loss = weights * mse_loss
        loss = torch.mean(weighted_loss)

        return loss

class CORR_LOSS(nn.Module):
    def __init__(self, threshold: float = 0.01):
        super().__init__()
        self.threshold = threshold

    def forward(self, preds: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:

        true_diffs = targets.unsqueeze(1) - targets.unsqueeze(0)
        pred_diffs = preds.unsqueeze(1) - preds.unsqueeze(0)

        vaild_indices = (true_diffs.abs() > self.threshold) & ~torch.isnan(true_diffs)

        loss = 1 - t_pearson(pred_diffs[vaild_indices], true_diffs[vaild_indices])

        return loss

class DELTA_LOSS(nn.Module):
    def __init__(self, weight_power: float = 0.0):
        super().__init__()
        self.weight_power = weight_power

    def forward(self, output: torch.Tensor, target: torch.Tensor) -> torch.Tensor:

        shuffled_indices = torch.randperm(output.size(0))
        shuffled_output = output[shuffled_indices]
        shuffled_target = target[shuffled_indices]

        pred_diff = output - shuffled_output  # [batch_size, num_labels]
        true_diff = target - shuffled_target  # [batch_size, num_labels]

        mse_loss = (pred_diff - true_diff) ** 2  # [batch_size, num_labels]

        weights = torch.abs(pred_diff)
        weights = weights ** self.weight_power
        
        weighted_loss = weights * mse_loss
        loss = torch.mean(weighted_loss)

        return loss