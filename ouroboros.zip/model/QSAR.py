import os
import time
import json
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
from .modules import (
    MultiPropDecoder, 
    optimizers_dict, 
    activation_dict,
    t_pearson,
    DELTA_LOSS,
    MATRIX_LOSS,
    CORR_LOSS
)
from utils.metrics import metric_functions, statistics_dict
from tqdm import tqdm
from .GeminiMol import GeminiMol

class QSAR(GeminiMol):
    def __init__(
            self, 
            model_name = None, 
            predictor_name = 'QSAR',
            batch_size = 512,
            predictor_info = {
                'smiles_name': 'smiles',
                'task_type': 'regression',
                'label_dict': {
                    'score': 'RMSE'
                }
            },
            params = {
                "hidden_dim": 1024,
                "dropout_rate": 0.1,
                "activation": 'SiLU',
                "projection_transform": 'Sigmoid',
                "linear_projection": False
            }
        ):
        super().__init__(
            model_path=model_name, 
            batch_size=batch_size,
            cache = True
        )
        torch.set_float32_matmul_precision('high')
        self.model_name = model_name
        self.predictor_name = predictor_name
        if os.path.exists(f'{self.model_name}/{self.predictor_name}/Decoder.pt'):
            self.predictor_info = json.load(
                open(
                    f'{self.model_name}/{self.predictor_name}/predictor.json', 
                    'r'
            ))
            params = json.load(
                open(
                    f'{self.model_name}/{self.predictor_name}/model_config.json', 
                    'r'
            ))
            self.label_list = list(self.predictor_info['label_dict'].keys())
            self.projector = nn.Sequential(
                nn.Dropout(p = 0.3),
                nn.Linear(
                    self.encoder_params['encoding_features'], 
                    params['hidden_dim'],
                ),
                activation_dict[params['activation']],
            )
            self.decoder = MultiPropDecoder(
                feature_dim = (self.encoder_params['encoding_features'], params['hidden_dim']),
                output_dim = len(self.label_list),
                **params
            )
            self.load()
        else:
            self.predictor_info = predictor_info
            os.makedirs(f'{self.model_name}/{self.predictor_name}', exist_ok=True)
            with open(
                f'{self.model_name}/{self.predictor_name}/predictor.json', 
                'w', 
                encoding='utf-8'
            ) as f:
                json.dump(predictor_info, f, ensure_ascii=False, indent=4)
            with open(
                f'{self.model_name}/{self.predictor_name}/model_config.json', 
                'w', 
                encoding='utf-8'
            ) as f:
                json.dump(params, f, ensure_ascii=False, indent=4)
            self.label_list = list(self.predictor_info['label_dict'].keys())
            self.projector = nn.Sequential(
                nn.Dropout(p = 0.3),
                nn.Linear(
                    self.encoder_params['encoding_features'], 
                    params['hidden_dim'],
                ),
                activation_dict[params['activation']],
            )
            self.decoder = MultiPropDecoder(
                feature_dim = (self.encoder_params['encoding_features'], params['hidden_dim']),
                output_dim = len(self.label_list),
                **params
            )
        self.projector.cuda()
        self.decoder.cuda()

    def load(self):
        if os.path.exists(f'{self.model_name}/{self.predictor_name}/Encoder.pt'):
            self.Encoder.load_state_dict(
                torch.load(f'{self.model_name}/{self.predictor_name}/Encoder.pt')
            )
        if os.path.exists(f'{self.model_name}/{self.predictor_name}/Projector.pt'):
            self.projector.load_state_dict(
                torch.load(f'{self.model_name}/{self.predictor_name}/Projector.pt')
            )
        if os.path.exists(f'{self.model_name}/{self.predictor_name}/Pooling.pt'):
            self.pooling.load_state_dict(
                torch.load(f'{self.model_name}/{self.predictor_name}/Pooling.pt')
            )
        if os.path.exists(f'{self.model_name}/{self.predictor_name}/Decoder.pt'):
            self.decoder.load_state_dict(
                torch.load(f'{self.model_name}/{self.predictor_name}/Decoder.pt')
            )

    def save(self):
        if self.encoder_finetune:
            torch.save(
                self.Encoder.state_dict(), 
                f"{self.model_name}/{self.predictor_name}/Encoder.pt"
            )
            torch.save(
                self.pooling.state_dict(), 
                f"{self.model_name}/{self.predictor_name}/Pooling.pt"
            )
        torch.save(
            self.projector.state_dict(), 
            f"{self.model_name}/{self.predictor_name}/Projector.pt"
        )
        torch.save(
            self.decoder.state_dict(), 
            f"{self.model_name}/{self.predictor_name}/Decoder.pt"
        )

    def forward(self, total_smiles_list):
        # Encode all sentences using the encoder
        features = self.encode(total_smiles_list)
        projected_feats = self.projector(features)
        # Calculate scores of encoded smiles
        return self.decoder(features, projected_feats)

    def predict_score(
            self, 
            df, 
            as_pandas=True
        ):
        self.eval()
        with torch.no_grad():
            pred_values = {key:[] for key in self.label_list}
            for i in tqdm(range(0, len(df), self.batch_size), desc=f'Predicting {self.predictor_name}'):
                rows = df.iloc[i:i+self.batch_size]
                total_smiles = rows[self.predictor_info['smiles_name']].to_list()
                pred = self.forward(total_smiles).cpu().detach().numpy()
                for k in range(len(self.label_list)):
                    pred_values[self.label_list[k]] += list(pred[:, k])
            if as_pandas == True:
                res_df = pd.DataFrame(pred_values)
                return res_df
            else:
                return pred_values

    def evaluate(
            self, 
            df
        ):
        pred_table = self.predict_score(
            df, 
            as_pandas=True
        )
        model_score = 0
        if len(self.label_list) == 1 and self.label_list[0] not in df.columns:
            potential_label = [
                label for label in df.columns 
                if label in ['Y', 'Label', 'label', 'pIC50', 'score', 'Score']
            ]
            label_col = [potential_label[0]]
        else:
            label_col = self.label_list
        results = pd.DataFrame(
                index=self.label_list, 
                columns=statistics_dict[self.predictor_info['task_type']]
            )
        for label_name in self.label_list:
            pred_score = pred_table[label_name].tolist()
            true_score = df[label_col[0]].tolist() if len(label_col) == 1 else df[label_name].tolist()
            for metric in statistics_dict[self.predictor_info['task_type']]:
                results.loc[[label_name],[metric]] = metric_functions[metric](true_score, pred_score)
            model_score += results[
                self.predictor_info['label_dict'][label_name]
            ].mean()
        print(results)
        return results, model_score / len(self.label_list)

    def loss_func(
        self,
        total_smiles,
        rows,
        label_col,
        loss_func
    ):
        pred = self.forward(total_smiles)
        true_m = torch.tensor(
            rows[label_col].values.tolist(), dtype = torch.float
        ).cuda()

        if self.predictor_info['task_type'] == 'binary' and loss_func == "BCE":
            weights = torch.tensor(
                [(1 - rows[label].mean()) for label in label_col]
            ).cuda()
            loss = torch.mean(
                nn.BCELoss(
                    reduction = 'none',
                )(
                    pred, true_m
                ) * weights
            )
        elif self.predictor_info['task_type'] == 'binary' and loss_func == "Ranking":
            true_v = true_m.view(-1)
            pos_scores = pred.squeeze(-1)[true_v == 1].unsqueeze(1)
            neg_scores = pred.squeeze(-1)[true_v == 0].unsqueeze(0)
            pairwise_diffs = pos_scores - neg_scores
            margin_loss = torch.mean(
                F.relu(0.1 - pairwise_diffs)
            )
            auc_loss = 1 - torch.mean(
                F.logsigmoid(pairwise_diffs)
            )
            loss = margin_loss + auc_loss
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "MSE":
            mes_loss = nn.MSELoss()(pred, true_m) 
            loss = mes_loss
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "Ranking":
            loss = (1 - t_pearson(pred, true_m)) + 20 * nn.MSELoss()(pred, true_m)
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "DELTA":
            loss = DELTA_LOSS(weight_power=0.0)(true_m.view(-1), pred.view(-1))
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "pDELTA":
            loss = DELTA_LOSS(weight_power=2.0)(true_m.view(-1), pred.view(-1))
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "MATRIX":
            loss = MATRIX_LOSS(weight_power=0.0)(pred.view(-1), true_m.view(-1))
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "pMATRIX":
            loss = MATRIX_LOSS(weight_power=2.0)(pred.view(-1), true_m.view(-1))
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "CORR":
            loss = CORR_LOSS(threshold=0.02)(pred.view(-1), true_m.view(-1))
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "Combined":
            loss = DELTA_LOSS(
                weight_power=4.0)(true_m.view(-1), pred.view(-1)
            ) + (1 - t_pearson(pred, true_m)) + 10 * nn.MSELoss()(pred, true_m)
        elif self.predictor_info['task_type'] == 'regression' and loss_func == "Probability":
            true_v = true_m.view(-1)
            pos_scores = pred.view(-1).squeeze(-1)[true_v > 0.6].unsqueeze(1)
            neg_scores = pred.view(-1).squeeze(-1)[true_v <= 0.4].unsqueeze(0)
            pairwise_diffs = pos_scores - neg_scores
            margin_loss = torch.mean(
                F.relu(0.2 - pairwise_diffs)
            )
            auc_loss = 1 - torch.mean(
                F.logsigmoid(pairwise_diffs)
            )
            delta_loss = DELTA_LOSS(weight_power=2.0)(pred.view(-1), true_v)
            loss = margin_loss + auc_loss + delta_loss
        else:
            raise ValueError(f"Unsupported loss function: {loss_func}")
        return loss

    def fit(
        self,
        train_set,
        val_set,
        epochs = 10,
        learning_rate = 1.0e-4,
        optim_type = 'AdamW',
        weight_decay = 0.01,
        patience = 50,
        frozen_steps = 1000,
        warmup_factor = 0.1, 
        num_warmup_steps = 1000,
        batch_group = 10,
        mini_epoch = 200,
        T_max = 1000, # setup consine LR params, lr = lr_max * 0.5 * (1 + cos( steps / T_max ))
        loss_func = "MSE",
    ):
        # Load the models and optimizers
        if optim_type not in optimizers_dict:
            print(f"Invalid optimizer type {optim_type}. Defaulting to AdamW.")
            optim_type = 'AdamW'
        print(f"NOTE: training the {self.predictor_name} model with {self.model_name} encoder.")
        # Set up the optimizer
        optimizer = optimizers_dict[optim_type](
            [
                {'params': self.decoder.parameters(), 'lr': learning_rate},
            ], 
            lr = learning_rate,
            weight_decay = weight_decay
        )
        self.encoder_finetune = False
        # set up the early stop params
        _, self.best_model_score = self.evaluate(val_set)
        print(f"NOTE: The initial model score is {round(self.best_model_score, 4)}.")
        counter = 0
        batch_id = 0
        # Apply warm-up learning rate
        if num_warmup_steps > 0:
            for param_group in optimizer.param_groups:
                param_group['lr'] = learning_rate * warmup_factor 
        # training
        start = time.time()
        start_batch_id = batch_id
        if len(self.label_list) == 1 and self.label_list[0] not in train_set.columns:
            potential_label = [
                label for label in train_set.columns 
                if label in ['Y', 'Label', 'label', 'pIC50', 'score', 'Score']
            ]
            label_col = [potential_label[0]]
        else:
            label_col = self.label_list
        for epoch in range(epochs):
            self.decoder.train()
            train_set = train_set.sample(frac=1)
            for i in range(0, len(train_set), self.batch_size):
                if batch_id == frozen_steps:
                    optimizer.add_param_group(
                        {'params': self.Encoder.parameters(), 'lr': learning_rate}
                    )
                    self.Encoder.train()
                    optimizer.add_param_group(
                        {'params': self.pooling.parameters(), 'lr': learning_rate}
                    )
                    self.pooling.train()
                    optimizer.add_param_group(
                        {'params': self.projector.parameters(), 'lr': learning_rate}
                    )
                    self.projector.train()
                    self.encoder_finetune = True
                batch_id += 1
                rows = train_set.iloc[i:i+self.batch_size]
                if len(rows) <= 2:
                    continue
                total_smiles = rows[self.predictor_info['smiles_name']].to_list()
                optimizer.zero_grad()
                # Calculate scores between encoded smiles
                loss = self.loss_func(
                    total_smiles,
                    rows,
                    label_col,
                    loss_func
                )
                loss.backward()
                optimizer.step()
                if batch_id % 20 == 0:
                    print(f"Epoch {epoch+1}, batch {batch_id}, time {round((time.time()-start)/(batch_id-start_batch_id), 2)}, train loss: {loss}")
                    start = time.time()
                    start_batch_id = batch_id
                if batch_id % batch_group == 0:
                    # Set up the learning rate scheduler
                    if batch_id < num_warmup_steps:
                        for param_group in optimizer.param_groups:
                            param_group['lr'] = learning_rate * ( warmup_factor + (1 - warmup_factor)* ( batch_id / num_warmup_steps) )
                    elif batch_id >= num_warmup_steps:
                        for param_group in optimizer.param_groups:
                            param_group['lr'] = learning_rate * 0.05 * (1 + 19 * np.cos( (batch_id % T_max)/T_max))
                if batch_id % mini_epoch == 0:
                    # Evaluation on validation set, if provided
                    _, val_model_score = self.evaluate(val_set)
                    self.decoder.train()
                    if self.encoder_finetune:
                        self.Encoder.train()
                        self.pooling.train()
                        self.projector.train()
                    if val_model_score > self.best_model_score or np.isnan(self.best_model_score):
                        self.best_model_score = val_model_score
                        self.save()
                        if counter > 0:
                            counter -= 1
                    else:
                        counter += 1
                    print(f"NOTE: Epoch {epoch+1}, batch {batch_id}, ValScore: {round(val_model_score, 4)}, patience: {patience-counter}")
                    if counter >= patience:
                        print("NOTE: The parameters was converged, stop training!")
                        break
            if counter >= patience:
                break
        _, val_model_score = self.evaluate(val_set)
        print(f"Training over! Evaluating on the validation set: {val_model_score}")
        if val_model_score > self.best_model_score:
            self.best_model_score = val_model_score
            self.save()
        print(f"Best Model Score: {self.best_model_score}")
        self.load()

    def fit_advanced(
        self,
        train_set,
        val_set,
        darkmatter,
        epochs = 10,
        learning_rate = 1.0e-4,
        optim_type = 'AdamW',
        weight_decay = 0.01,
        patience = 50,
        frozen_steps = 1000,
        warmup_factor = 0.1, 
        num_warmup_steps = 1000,
        batch_group = 10,
        mini_epoch = 200,
        T_max = 1000, # setup consine LR params, lr = lr_max * 0.5 * (1 + cos( steps / T_max ))
        loss_func = "MSE",
    ):
        # Load the models and optimizers
        if optim_type not in optimizers_dict:
            print(f"Invalid optimizer type {optim_type}. Defaulting to AdamW.")
            optim_type = 'AdamW'
        print(f"NOTE: training the {self.predictor_name} model with {self.model_name} encoder.")
        # Set up the optimizer
        optimizer = optimizers_dict[optim_type](
            [
                {'params': self.decoder.parameters(), 'lr': learning_rate},
            ], 
            lr = learning_rate,
            weight_decay = weight_decay
        )
        self.encoder_finetune = False
        # set up the early stop params
        _, self.best_model_score = self.evaluate(val_set)
        print(f"NOTE: The initial model score is {round(self.best_model_score, 4)}.")
        counter = 0
        batch_id = 0
        # Apply warm-up learning rate
        if num_warmup_steps > 0:
            for param_group in optimizer.param_groups:
                param_group['lr'] = learning_rate * warmup_factor 
        # training
        start = time.time()
        start_batch_id = batch_id
        if len(self.label_list) == 1 and self.label_list[0] not in train_set.columns:
            potential_label = [
                label for label in train_set.columns 
                if label in ['Y', 'Label', 'label', 'pIC50', 'score', 'Score']
            ]
            label_col = [potential_label[0]]
        else:
            label_col = self.label_list
        for label in label_col:
            darkmatter[label] = train_set[label].min()
        for epoch in range(epochs):
            self.decoder.train()
            epoch_set = pd.concat(
                [train_set, darkmatter.sample(n=len(train_set)//3)], ignore_index=True
            ).sample(frac=1)
            for i in range(0, len(epoch_set), self.batch_size):
                if batch_id == frozen_steps:
                    optimizer.add_param_group(
                        {'params': self.Encoder.parameters(), 'lr': learning_rate}
                    )
                    self.Encoder.train()
                    optimizer.add_param_group(
                        {'params': self.pooling.parameters(), 'lr': learning_rate}
                    )
                    self.pooling.train()
                    optimizer.add_param_group(
                        {'params': self.projector.parameters(), 'lr': learning_rate}
                    )
                    self.projector.train()
                    self.encoder_finetune = True
                batch_id += 1
                rows = epoch_set.iloc[i:i+self.batch_size]
                if len(rows) <= 2:
                    continue
                total_smiles = rows[self.predictor_info['smiles_name']].to_list()
                optimizer.zero_grad()
                # Calculate scores between encoded smiles
                loss = self.loss_func(
                    total_smiles,
                    rows,
                    label_col,
                    loss_func
                )
                loss.backward()
                optimizer.step()
                if batch_id % 20 == 0:
                    print(f"Epoch {epoch+1}, batch {batch_id}, time {round((time.time()-start)/(batch_id-start_batch_id), 2)}, train loss: {loss}")
                    start = time.time()
                    start_batch_id = batch_id
                if batch_id % batch_group == 0:
                    # Set up the learning rate scheduler
                    if batch_id < num_warmup_steps:
                        for param_group in optimizer.param_groups:
                            param_group['lr'] = learning_rate * ( warmup_factor + (1 - warmup_factor)* ( batch_id / num_warmup_steps) )
                    elif batch_id >= num_warmup_steps:
                        for param_group in optimizer.param_groups:
                            param_group['lr'] = learning_rate * 0.05 * (1 + 19 * np.cos( (batch_id % T_max)/T_max))
                if batch_id % mini_epoch == 0:
                    # Evaluation on validation set, if provided
                    _, val_model_score = self.evaluate(val_set)
                    self.decoder.train()
                    if self.encoder_finetune:
                        self.Encoder.train()
                        self.pooling.train()
                        self.projector.train()
                    if val_model_score > self.best_model_score or np.isnan(self.best_model_score):
                        self.best_model_score = val_model_score
                        self.save()
                        if counter > 0:
                            counter -= 1
                    else:
                        counter += 1
                    print(f"NOTE: Epoch {epoch+1}, batch {batch_id}, ValScore: {round(val_model_score, 4)}, patience: {patience-counter}")
                    if counter >= patience:
                        print("NOTE: The parameters was converged, stop training!")
                        break
            if counter >= patience:
                break
        _, val_model_score = self.evaluate(val_set)
        print(f"Training over! Evaluating on the validation set: {val_model_score}")
        if val_model_score > self.best_model_score:
            self.best_model_score = val_model_score
            self.save()
        print(f"Best Model Score: {self.best_model_score}")
        self.load()