import os
import sys
import torch
import pandas as pd
import numpy as np
from model.Ouroboros import Ouroboros
from utils.chem import gen_standardize_smiles, check_smiles_validity, is_valid_smiles
import gc

class PharmProfiler:
    def __init__(self, 
            encoder, 
            standardize = False
        ):
        self.encoder = encoder
        self.probes_dict = {
            # name : { 
            # 'smiles': smiles_list: 
            # 'weight': weight (float) 
            # }
        }
        self.standardize = standardize

    def prepare(self, dataset, smiles_column='smiles'):
        if self.standardize == True:
            dataset[smiles_column] = dataset[smiles_column].apply(
                lambda x:gen_standardize_smiles(x, kekule=False)
            )
        else:
            dataset[smiles_column] = dataset[smiles_column].apply(
                lambda x:check_smiles_validity(x)
            )
        dataset = dataset[dataset[smiles_column]!='smiles_unvaild']
        return dataset.reset_index(drop=True)

    def update_probes(self, 
        name,
        smiles_list, 
        weight
    ):
        for smiles in smiles_list:
            assert is_valid_smiles(smiles), f'Error: the probe {smiles} is invalid.'
        self.probes_dict[name] = {
            'smiles': smiles_list,
            'weight': weight
        }

    def update_library(self,
        compound_library,
        prepare = True,
        smiles_column = 'smiles',
    ):
        if prepare:
            compound_library = self.prepare(compound_library, smiles_column=smiles_column)
        print(f'NOTE: the compound library contains {len(compound_library)} compounds.')
        compound_library.drop_duplicates(
            subset = [smiles_column],
            keep='first',
            inplace = True,
            ignore_index = True
        )
        print(f'NOTE: non-duplicates compound library contains {len(compound_library)} compounds.')
        self.database = self.encoder.create_database(
            compound_library, 
            smiles_column = smiles_column, 
            worker_num = 3
        )
        print('NOTE: features database was created.')
        gc.collect()
        return self.database

    def __call__(
        self, 
        smiles_column = 'smiles',
        probe_cluster = False,
        smiliarity_metrics = 'Cosine',
        flooding = 0.0,
        threshold = 0.5
    ):
        print(f'NOTE: columns of feature database: {self.database.columns}')
        print(f'NOTE: starting screening...')
        score_list = []
        for name, probe in self.probes_dict.items():
            print(f'NOTE: using {name} as the probe....', end='')
            probe_list = probe['smiles']
            gc.collect()
            if probe_cluster:
                probe_res = self.encoder.virtual_screening(
                    probe_list, 
                    self.database, 
                    input_with_features = True,
                    smiles_column = smiles_column, 
                    return_all_col = False,
                    similarity_metrics = [smiliarity_metrics],
                    worker_num = 24
                )
                probe_res.sort_values(smiliarity_metrics, ascending=False, inplace=True)
                probe_res.drop_duplicates(
                    subset = [smiles_column], 
                    keep = 'first', 
                    inplace = True,
                    ignore_index = True
                )
                probe_res[smiliarity_metrics] = probe_res[smiliarity_metrics].apply(
                    lambda x: x if x > flooding else 0.0
                )
                probe_res[f'{name}'] = probe['weight'] * probe_res[smiliarity_metrics]
                self.database = pd.merge(
                    self.database,
                    probe_res[[smiles_column, f'{name}']], 
                    on = smiles_column
                )
                score_list.append(f'{name}')
            else:
                for i in range(len(probe_list)):
                    probe_res = self.encoder.virtual_screening(
                        [probe['smiles'][i]], 
                        self.database, 
                        input_with_features = True,
                        smiles_column = smiles_column, 
                        return_all_col = False,
                        similarity_metrics = [smiliarity_metrics],
                        worker_num = 24
                    )
                    probe_res[smiliarity_metrics] = probe_res[smiliarity_metrics].apply(
                        lambda x: x if x > flooding else 0.0
                    )
                    probe_res[f'{name}_{i}'] = probe['weight'] * probe_res[smiliarity_metrics]
                    self.database = pd.merge(
                        self.database,
                        probe_res[[smiles_column, f'{name}_{i}']], 
                        on = smiles_column
                    )
                    score_list.append(f'{name}_{i}')
            print('Done!')
            probe_res = None
            gc.collect()
        self.database['SimScore'] = self.database[score_list].sum(axis=1)
        self.database = self.database[self.database['SimScore'] > 0]
        self.database['SimScore'] = np.maximum(self.database[score_list] - flooding, 0).sum(axis=1)
        self.database, properties_names = self.encoder.properties_prediction(
            self.database,
            input_with_features = True,
            smiles_column = smiles_column,
            worker_num = 3,
        )
        res_columns = [x for x in self.database.columns if x != 'features'] 
        total_res = self.database[res_columns]
        gc.collect()
        if len(properties_names) > 0:
            for target in properties_names:
                print(f'NOTE: {target}: max {total_res[target].max()}, min {total_res[target].min()}, mean {total_res[target].mean()}')
            off_targets = [
                target for target in properties_names
                if self.encoder.predictor_goals[target] <= threshold
            ]
            for off_target in off_targets:
                total_res = total_res[total_res[off_target] <= threshold]
                print(f'NOTE: filter {off_target}: {len(total_res)}.')
            for target in properties_names:
                print(f'NOTE: {target}: max {total_res[target].max()}, min {total_res[target].min()}, mean {total_res[target].mean()}')
            on_targets = [
                target
                for target in properties_names
                if self.encoder.predictor_goals[target] > threshold
            ]
            for on_t in on_targets:
                total_res[f'B_{on_t}'] = total_res[f'{on_t}'].apply(lambda x: 1 if x > threshold else 0)
            total_res['PropScore'] = np.maximum(total_res[on_targets] - threshold, 0).mean(axis=1)
            total_res['OnTarget'] = total_res[[f'B_{on_t}' for on_t in on_targets]].sum(axis=1)
            total_res = total_res[total_res['OnTarget'] > 0]
            total_res['Score'] = total_res['SimScore'] * total_res['PropScore']
        else:
            total_res['Score'] = total_res['SimScore']
        return total_res

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    ## load model
    model_name = sys.argv[1]
    predictor_info = {}
    if not sys.argv[2] in ['Fasle', 'None', 'F', 'No', 'N', 'no', 'false', 'none']:
        for propery in sys.argv[2].split(','):
            predictor_info[propery.split('@')[0]] = float(propery.split('@')[1])
    encoder = Ouroboros(
        model_name,
        batch_size = 1024,
        predictor_info = predictor_info,
        generator = False,
        flooding = [0.3, 0.6], # CSS sim, 2D sim, min sim
        threads = 40
    )
    predictor = PharmProfiler(
        encoder,
        standardize = True
    )
    # job_name
    job_name = sys.argv[3]
    smiles_col = sys.argv[4]
    # update profiles
    ref_smiles_table = pd.read_csv(sys.argv[6])
    if sys.argv[7] not in ['Fasle', 'None', 'F', 'No', 'N', 'no', 'false', 'none']:
        group_param = sys.argv[7].split(':')
        if len(group_param) == 1:
            label_col = group_param[0]
            for group in ref_smiles_table[label_col].to_list(): 
                if isinstance(group, float):
                    predictor.update_probes(
                        name = f'w_{group}',
                        smiles_list = ref_smiles_table[
                            ref_smiles_table[label_col]==group
                        ][smiles_col].to_list(),
                        weight = group
                        )
                else:
                    predictor.update_probes(
                        name = f'{group}',
                        smiles_list = ref_smiles_table[
                            ref_smiles_table[label_col]==group
                        ][smiles_col].to_list(),
                        weight = 1.0
                    )
        elif len(group_param) == 2:
            label_col = group_param[0]
            weight_col = group_param[1]
            for group in ref_smiles_table[label_col].to_list():
                assert len(ref_smiles_table[ref_smiles_table[label_col]==group][weight_col].to_list()), "Error: profile weight no more than 2!"
                weight = ref_smiles_table[ref_smiles_table[label_col]==group][weight_col].to_list()[0]
                predictor.update_probes(
                    name = f'{group}',
                    smiles_list = ref_smiles_table[ref_smiles_table[label_col]==group][smiles_col].to_list(),
                    weight = weight
                )
        else:
            assert len(group_param) <= 2, "Error: profile tags no more than 2!"
    else:
        predictor.update_probes(
            name = 'active',
            smiles_list = ref_smiles_table[smiles_col].to_list(),
            weight = 1.0
        )
    probe_cluster = True if sys.argv[8] in [
        'True', 'true', 'T', 't', 'Yes', 'yes', 'Y', 'y'
    ] else False
    flooding = float(sys.argv[9])
    threshold = float(sys.argv[10])
    # generate features database
    library_name = f'{os.path.splitext(os.path.basename(sys.argv[5]))[0]}' 
    if os.path.exists(f'{library_name}.pkl'):
        predictor.database = pd.read_pickle(f'{library_name}.pkl')
    elif os.path.exists(f'{model_name}/{library_name}.pkl'):
        predictor.database = pd.read_pickle(f'{model_name}/{library_name}.pkl')
    else:
        compound_library = pd.read_csv(sys.argv[5])
        features_database = predictor.update_library(
            compound_library,
            prepare = True,
            smiles_column = smiles_col,
        )
        # save database to parquet
        features_database.to_pickle(f'{model_name}/{library_name}.pkl')
        del compound_library
        del features_database
        gc.collect()
    # virtual screening 
    total_res = predictor(
        smiles_column = smiles_col,
        probe_cluster = probe_cluster,
        flooding = flooding,
        threshold = threshold,
    )
    total_res.sort_values('Score', ascending=False, inplace=True)
    total_res.to_csv(f"{job_name}_results.csv", index=False, header=True, sep=',')
    print(f'NOTE: job completed! check {job_name}_results.csv for results!')

