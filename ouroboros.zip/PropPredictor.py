import os
import sys
import pandas as pd
from model.Ouroboros import Ouroboros
from utils.chem import prepare

if __name__ == "__main__":
    model_name = sys.argv[1]
    smiles_col = sys.argv[2]
    extrnal_data = pd.read_csv(sys.argv[3])
    job_name = f'{os.path.splitext(os.path.basename(sys.argv[3]))[0]}_{os.path.basename(sys.argv[1])}'
    prop_list = sys.argv[4]
    extrnal_data = prepare(extrnal_data, smiles_column = smiles_col, standardize = False)
    original_columns = extrnal_data.columns.to_list()
    core_columns = []
    std_columns = []
    predictor_cols = []
    final_results = extrnal_data.copy()
    print('NOTE: loading models...')
    for proptery in [ 
        p.strip() 
        for p in open(prop_list).readlines() 
    ]:
        results = extrnal_data.copy()
        res_cols = []
        for model_no in ['1', '2', '3', '4', '5', '6']:
            predictor_name = f'{proptery}_{model_no}'
            if os.path.exists(f'{model_name}/{predictor_name}/Decoder.pt'):
                ## read the predictor models
                predictor = Ouroboros(
                    model_name = model_name, 
                    batch_size = 512,
                    predictor_info = {predictor_name: 1.0},
                    generator = False
                )
                ## prepare
                print(f'NOTE: make {predictor_name} predictions...')
                results = predictor.predict_scores(results, smiles_column = smiles_col)
                res_cols.append(predictor_name)
                final_results[predictor_name] = results[predictor_name.replace('.', '_')]
        if len(res_cols) > 0:
            final_results[f'{proptery}'] = final_results[res_cols].mean(axis=1)
            final_results[f'{proptery}_std'] = final_results[res_cols].std(axis=1)
            core_columns.append(f'{proptery}')
            std_columns.append(f'{proptery}_std')
        predictor_cols += res_cols
    ## output the results
    final_results[original_columns+core_columns+std_columns+predictor_cols].to_csv(
        f"{job_name}_predictions.csv", 
        index=False, 
        header=True, 
        sep=','
    )
    print(f'NOTE: job completed! check {job_name}_predictions.csv for results!')




    