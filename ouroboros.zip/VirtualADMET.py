import os
import sys
import torch
import pandas as pd
import numpy as np
from model.Ouroboros import Ouroboros
from utils.chem import prepare
import gc

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    ## load model
    model_name = sys.argv[1]
    smiles_col = sys.argv[2]
    extrnal_data = pd.read_csv(sys.argv[3])
