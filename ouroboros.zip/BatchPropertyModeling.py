import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '.'))
import torch
import random
import numpy as np
import pandas as pd
from model.QSAR import QSAR
from utils.metrics import metric_functions, statistics_dict

partition_list = [
    'replica_1',
    'replica_2',
    'replica_3',
]

metric_list = [
    'MCC/SPEARMANR',
    'AUPRC/PEARSONR',
    'ACC/RMSE',
    'AUROC/KENDALLTAU',
]

label_column_names = [
    'pChEMBL', 
    'pChEMBL_Value',
    'pChEMBL Value',
    'Standard_Value',
    'Label',
    'pIC50',
    'Y',
    'label',
    'score',
    'Score'
]

def benchmark_qsar(
    model_name,
    data_path,
    benchmark = 'MolecularNavigation',
):
    task_list = os.listdir(f'{data_path}/{benchmark}/')
    task_list = [os.path.splitext(task)[0] for task in task_list]
    benchmark_results = pd.DataFrame(
            columns = ['Score', 'Task'] + [
                f'{partition}_{metric}'
                for partition in partition_list
                for metric in metric_list
            ], 
            index = task_list
        )
    single_model_results = []
    for task in task_list:
        print(f'NOTE: evaluating on the {task}.....')
        dataset = pd.read_csv(f'{data_path}/{benchmark}/{task}.csv')
        label_column = [
            col for col in dataset.columns if col in label_column_names
        ][0]
        task_type = 'regression' if len(dataset[label_column].unique().tolist()) > 2 else 'binary'
        loss_func = "MSE" if task_type == 'regression' else "BCE"
        model_id = 1
        benchmark_results.loc[[task], ['Task']] = task_type
        score_dict = {}
        for partition in partition_list:
            if f'{partition}' not in dataset.columns:
                continue
            training_data = dataset[dataset[f'{partition}'] == 'train']
            val_data = dataset[dataset[f'{partition}'] == 'valid']
            test_data = dataset[dataset[f'{partition}'] == 'test']
            # set hyper-parameters based on the number of training samples
            if len(training_data) > 1024:
                batch_size, learning_rate, batch_group, optim = 256, 5.0e-5, 10, 'AdamW'
            elif len(training_data) > 256:
                batch_size, learning_rate, batch_group, optim = 128, 3.0e-5, 10, 'AdamW'
            else:
                batch_size, learning_rate, batch_group, optim = 64, 1.0e-5, 5, 'L-AdamW'
            model = QSAR(
                model_name = model_name,
                predictor_name = f'{task}_{model_id}',
                batch_size = batch_size,
                predictor_info = {
                    'smiles_name': 'SMILES',
                    'task_type': task_type,
                    'label_dict': {
                        task: statistics_dict[task_type][0], 
                    }
                },
                params = {
                    "hidden_dim": 12288, # between 2048 and 12288
                    "dropout_rate": 0.1, 
                    "activation": 'SiLU', # GELU, SiLU, ReLU, LeakyReLU
                    "projection_transform": 'Sigmoid',
                    "linear_projection": False,
                }
            )
            if not os.path.exists((f'{model_name}/{task}_{model_id}/Decoder.pt')):
                model.fit(
                    train_set = training_data,
                    val_set = val_data,
                    epochs = (batch_group*2000*batch_size // len(training_data))+1,
                    learning_rate = learning_rate,
                    optim_type = optim,
                    weight_decay = 0.01,
                    patience = 30,
                    frozen_steps = 999999999999999,
                    warmup_factor = 0.1, 
                    num_warmup_steps = batch_group*200,
                    T_max = batch_group*200,
                    batch_group = batch_group,
                    mini_epoch = batch_group*40,
                    loss_func = loss_func,
                )
                if model.best_model_score >= 0.5:
                    print(f'NOTE: {task}_{model_id} trained successfully!')
            else:
                print(f'NOTE: {task}_{model_id} already trained, skip training!')
            pred_res = model.predict_score(test_data)
            true_score = test_data[label_column].to_list()
            pred_score = pred_res[task].to_list()
            # calculate metrics
            for metric in metric_list:
                c_mertic = metric.split('/')[0] if task_type == 'binary' else metric.split('/')[1]
                benchmark_results.loc[
                    [task],[f'{partition}_{metric}']
                ] = metric_functions[c_mertic](true_score, pred_score)
            if task_type == 'binary':
                score_dict[f'{task}_{model_id}'] = metric_functions['MCC'](true_score, pred_score) 
            else:
                score_dict[f'{task}_{model_id}'] = metric_functions['SPEARMANR'](true_score, pred_score)
            single_model_results.append(
                {
                    'task': task,
                    'task_type': task_type,
                    'model_name': os.path.basename(model_name),
                    'model_id': f'{task}_{model_id}',
                    'partition': partition,
                    'MCC/SPEARMANR': score_dict[f'{task}_{model_id}'],
                    'AUPRC/PEARSONR': metric_functions['AUPRC'](true_score, pred_score) if task_type == 'binary' else metric_functions['PEARSONR'](true_score, pred_score),
                    'AUROC/KENDALLTAU': metric_functions['AUROC'](true_score, pred_score) if task_type == 'binary' else metric_functions['KENDALLTAU'](true_score, pred_score),
                }
            )
            model_id += 1
        benchmark_results.loc[[task], ['Score']] = np.mean(list(score_dict.values()))
        print(f'NOTE: {task} {task_type} {round(benchmark_results.loc[[task], ["Score"]].values[0][0],4)}, {score_dict}')
        benchmark_results.dropna(
            how = 'all',
            axis = 1,
            inplace = True
        )
        model_card = pd.DataFrame(single_model_results)
    return benchmark_results, model_card

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    # read data and build dataset
    data_path = sys.argv[1]
    model_name = sys.argv[2]
    benchmark = sys.argv[3]
    # set training params
    training_random_seed = random.randint(0, 9999)
    torch.manual_seed(training_random_seed)
    torch.cuda.manual_seed(training_random_seed) 
    torch.cuda.manual_seed_all(training_random_seed)
    print(f'NOTE: training random seed is {training_random_seed}')
    benchmark_results, model_card = benchmark_qsar(
        model_name, 
        data_path = data_path,
        benchmark = benchmark,
    )
    print(benchmark_results)
    benchmark_results.to_csv(f'{os.path.basename(model_name)}_{benchmark}_results.csv')
    model_card.to_csv(f'{os.path.basename(model_name)}_{benchmark}_model_card.csv', index = False)
            