import os
import sys
import torch
import pandas as pd
import numpy as np
from model.Ouroboros import Ouroboros
import gc

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    ## load model
    model_name = sys.argv[1]
    prop_list = sys.argv[2]
    properties_names = [ 
        p.strip() 
        for p in open(prop_list).readlines() 
    ]
    # job_name
    job_name = sys.argv[3]
    smiles_col = sys.argv[4]
    library_path = sys.argv[5]
    # generate features database
    library_name = f'{os.path.splitext(os.path.basename(library_path))[0]}' 
    if os.path.exists(f'{library_name}.pkl'):
        dataset = pd.read_pickle(f'{library_name}.pkl')
    elif os.path.exists(f'{model_name}/{library_name}.pkl'):
        dataset = pd.read_pickle(f'{model_name}/{library_name}.pkl')
    else:
        compound_library = pd.read_csv(library_path)
        predictor = Ouroboros(
            model_name,
            batch_size = 1024,
            predictor_info = {},
            generator = False,
            threads = 40
        )
        dataset = predictor.create_database(
            compound_library, 
            smiles_column = smiles_col, 
            worker_num = 3
        )
        # save database to pickle
        dataset.to_pickle(f'{model_name}/{library_name}.pkl')
        del compound_library
        gc.collect()
    # predict properties
    keep_raw = False
    keep_std = True
    output_cols = [x for x in dataset if x != 'features'] 
    for proptery in list(set(properties_names)):
        res_cols = []
        for model_no in ['1', '2', '3', '4', '5', '6']:
            predictor_name = f'{proptery}_{model_no}'
            if os.path.exists(f'{model_name}/{predictor_name}/Decoder.pt'):
                predictor = Ouroboros(
                    model_name,
                    batch_size = 3072,
                    predictor_info = {predictor_name: 1.0},
                    generator = False,
                    threads = 40
                )
                ## prepare
                print(f'NOTE: make predictions {predictor_name}...')
                dataset, _ = predictor.properties_prediction(
                    dataset, 
                    input_with_features = True,
                    smiles_column = smiles_col,
                    worker_num = 3,
                )
                if '.' in predictor_name:
                    res_cols.append(predictor_name.replace('.', '_'))
                else:
                    res_cols.append(predictor_name)
        dataset[f'{proptery}'] = dataset[res_cols].mean(axis=1)
        if keep_std:
            dataset[f'{proptery}_std'] = dataset[res_cols].std(axis=1)
            output_cols.append(f'{proptery}_std')
        output_cols.append(f'{proptery}')
        if keep_raw:
            output_cols += res_cols
        else:
            for col_name in res_cols:
                del dataset[col_name]
    dataset[output_cols].to_csv(f"{job_name}_results.csv", index=False, header=True, sep=',')
    print(f'NOTE: job completed! check {job_name}_results.csv for results!')

