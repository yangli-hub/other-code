import sys
import pandas as pd
import torch
from model.Ouroboros import Ouroboros

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    # read data and build dataset
    dataset = pd.read_csv(sys.argv[1])
    model_name = sys.argv[2]
    smiles_col = sys.argv[3]
    title_col = sys.argv[4]
    # set training params
    training_random_seed = 1207
    torch.manual_seed(training_random_seed)
    torch.cuda.manual_seed(training_random_seed) 
    torch.cuda.manual_seed_all(training_random_seed)
    ouroboros_model = Ouroboros(
        model_path = model_name,
        predictor_info = {},
        batch_size = 1024
    )
    for title, smiles in zip(
        dataset[title_col].to_list(), 
        dataset[smiles_col].to_list()
    ):
        ouroboros_model.drawmol(
            [smiles],
            prefix = title
        )


