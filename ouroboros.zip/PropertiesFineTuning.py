import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '.'))
import torch
import random
import numpy as np
import pandas as pd
from model.QSAR import QSAR
from utils.metrics import metric_functions

partition_list = [
    'replica_1',
    'replica_2',
    'replica_3',
]

dataset_base_cols = [
    'SMILES',
    'Title',
    'partition',
    'ID',
    'Name',
    'NSC',
    'CAS',
    'CID',
    'ChEMBL_ID',
    'PubChem_ID',
]

metric_list = [
    'MCC/SPEARMANR',
    'AUPRC/PEARSONR',
    'ACC/RMSE',
    'AUROC/KENDALLTAU',
]

batch_size_dict = {
    'BCE': 256,
    'MSE': 256,
    'Ranking': 256,
    'DELTA': 128,
    'pDELTA': 128,
    'MATRIX': 12,
    'pMATRIX': 12,
    'CORR': 12,
    'Combined': 128,
    'Probability': 64,
}

def benchmark_qsar(
    model_name,
    dataset,
    dataset_name = None,
    loss_func = 'DELTA',  # 'BCE' for binary, 'MSE' for regression
):
    label_column_names = [ 
        label for label in dataset.columns.to_list() 
        if label not in dataset_base_cols + partition_list
    ]
    task_type = 'regression' if dataset[label_column_names].nunique().max() > 2 else 'binary'
    benchmark_results = pd.DataFrame(
            columns = ['Score'] + [
                f'{partition}_{metric}'
                for partition in partition_list
                for metric in metric_list
            ], 
            index = label_column_names
        )
    single_model_results = []
    model_id = 1
    score_dict = {}
    for partition in partition_list:
        if f'{partition}' not in dataset.columns:
            continue
        training_data = dataset[dataset[f'{partition}'] == 'train']
        val_data = dataset[dataset[f'{partition}'] == 'valid']
        test_data = dataset[dataset[f'{partition}'] == 'test']
        # set hyper-parameters based on the number of training samples
        bacth_factor, learning_rate, batch_group, optim = 1, 5.0e-5, 5, 'AdamW'
        batch_size = int(batch_size_dict[loss_func] * bacth_factor)
        model = QSAR(
            model_name = model_name,
            predictor_name = f'{dataset_name}_{model_id}',
            batch_size = batch_size,
            predictor_info = {
                'smiles_name': 'SMILES',
                'task_type': task_type,
                'label_dict': {
                    task: 'KENDALLTAU' if task_type == 'regression' else 'AUROC'
                    for task in label_column_names
                }
            },
            params = {
                "hidden_dim": max(12288, len(label_column_names) * 4),
                "dense_dim": max(1024, len(label_column_names) * 2),
                "dropout_rate": 0.1, 
                "activation": 'SiLU', # GELU, SiLU, ReLU, LeakyReLU
                "projection_transform": 'Sigmoid',
                "linear_projection": False,
            }
        )
        if not os.path.exists((f'{model_name}/{dataset_name}_{model_id}/Decoder.pt')):
            model.fit(
                train_set = training_data,
                val_set = val_data,
                epochs = (batch_group*2000*batch_size // len(training_data))+1,
                learning_rate = learning_rate,
                optim_type = optim,
                weight_decay = 0.01,
                patience = 30,
                frozen_steps = batch_group*100,
                warmup_factor = 0.1, 
                num_warmup_steps = batch_group*200,
                T_max = batch_group*200,
                batch_group = batch_group,
                mini_epoch = batch_group*30,
                loss_func = loss_func,
            )
            if model.best_model_score >= 0.5:
                print(f'NOTE: {dataset_name}_{model_id} trained successfully!')
        else:
            print(f'NOTE: {dataset_name}_{model_id} already trained, skip training!')
        pred_res = model.predict_score(test_data)
        model_id += 1
        for task in label_column_names:
            true_score = test_data[task].to_list()
            pred_score = pred_res[task].to_list()
            # calculate metrics
            for metric in metric_list:
                c_mertic = metric.split('/')[0] if task_type == 'binary' else metric.split('/')[1]
                benchmark_results.loc[
                    [task],[f'{partition}_{metric}']
                ] = metric_functions[c_mertic](true_score, pred_score)
            if task_type == 'binary':
                score_dict[f'{task}_{model_id}'] = metric_functions['MCC'](true_score, pred_score) 
            else:
                score_dict[f'{task}_{model_id}'] = metric_functions['SPEARMANR'](true_score, pred_score)
            single_model_results.append(
                {
                    'task': dataset_name if len(label_column_names) == 1 else task,
                    'task_type': task_type,
                    'model_name': os.path.basename(model_name),
                    'model_id': f'{dataset_name}_{model_id}',
                    'partition': partition,
                    'MCC/SPEARMANR': score_dict[f'{task}_{model_id}'],
                    'AUPRC/PEARSONR': metric_functions['AUPRC'](true_score, pred_score) if task_type == 'binary' else metric_functions['PEARSONR'](true_score, pred_score),
                    'AUROC/KENDALLTAU': metric_functions['AUROC'](true_score, pred_score) if task_type == 'binary' else metric_functions['KENDALLTAU'](true_score, pred_score),
                }
            )
    print(f'NOTE: {dataset_name} {task_type} {benchmark_results["Score"].mean()}, {score_dict}')
    benchmark_results.dropna(
        how = 'all',
        axis = 1,
        inplace = True
    )
    model_card = pd.DataFrame(single_model_results)
    return benchmark_results, model_card

if __name__ == '__main__':
    # check GPU
    print('CUDA available:', torch.cuda.is_available())  # Should be True
    print('CUDA capability:', torch.cuda.get_arch_list()) 
    print('GPU number:', torch.cuda.device_count())  # Should be > 0
    # read data and build dataset
    dataset = pd.read_csv(sys.argv[1])
    dataset_name = os.path.splitext(os.path.basename(sys.argv[1]))[0]
    model_name = sys.argv[2]
    loss_func = sys.argv[3]
    # set training params
    training_random_seed = random.randint(0, 9999)
    torch.manual_seed(training_random_seed)
    torch.cuda.manual_seed(training_random_seed) 
    torch.cuda.manual_seed_all(training_random_seed)
    print(f'NOTE: training random seed is {training_random_seed}')
    benchmark_results, model_card = benchmark_qsar(
        model_name, 
        dataset = dataset,
        dataset_name = dataset_name,
        loss_func = loss_func
    )
    print(benchmark_results)
    benchmark_results.to_csv(f'{os.path.basename(model_name)}_{dataset_name}_results.csv')
    model_card.to_csv(f'{os.path.basename(model_name)}_{dataset_name}_model_card.csv', index = False)
            