import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import pandas as pd

smiles_column_names = [
    'SMILES', 'smiles', 'Smiles', 'Drug', 'Compound', 'smiles_standarized',
    'Molecule', 'Molecular_SMILES', 'Molecular SMILES',
]

title_column_names = [
    'Title', 'ID', 'No', 'CAS', 'PubChemID', 'ChEMBLID'
]

if __name__ == '__main__':
    dataset_path = sys.argv[1]
    output_path = sys.argv[2]
    dataset = pd.read_pickle(
        dataset_path
    )
    data_table_columns = dataset.columns
    smiles_column = [
        col for col in data_table_columns if col in smiles_column_names
    ][0]
    title_column = [
        col for col in data_table_columns if col in title_column_names
    ][0]
    dataset[[smiles_column, title_column]].to_csv(
        output_path, index=False
    )