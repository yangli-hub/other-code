import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from fingerprint import Fingerprint
from chem import gen_standardize_smiles, get_skeleton
from metrics import cluster_models, reduce_dimension
from scipy.stats import boxcox

smiles_column_names = [
    'SMILES', 'smiles', 'Smiles', 'Drug', 'Compound', 'smiles_standarized',
    'Molecule', 'Molecular_SMILES', 'Molecular SMILES',
]

label_column_names = [
    'pChEMBL', 
    'pChEMBL_Value',
    'pChEMBL Value',
    'Standard_Value',
    'Label',
    'pIC50',
    'Y',
    'label',
    'score',
    'Score',
    'Inhibition',
    'Residual Activity',
    'Emax',
    'IC50',
    'EC50',
]

def prepare(
    dataset,
    dataset_name,
    smiles_column,
    label_column,
):
    print(f"NOTE: {dataset_name} dataset size ({len(dataset)})")
    dataset[smiles_column] = dataset[smiles_column].apply(lambda x:gen_standardize_smiles(x))
    dataset = dataset[dataset[smiles_column]!='smiles_unvaild']
    dataset = dataset.dropna(subset=[smiles_column, label_column], how='any')
    dataset = dataset.reset_index(drop=True)
    print(f"NOTE: processed {dataset_name} dataset size ({len(dataset)})")
    print(f"NOTE: {dataset_name} statistics, max: {dataset[label_column].max()}, min: {dataset[label_column].min()}, mean: {dataset[label_column].mean()}, std: {dataset[label_column].std()}")
    if len(set(dataset[label_column])) == 2:
        print(f'NOTE: {dataset_name} dataset is binary classification.')
    else:
        print(f'NOTE: {dataset_name} dataset is regression.')
        original_skew = dataset[label_column].skew()
        if original_skew < 1.0 and original_skew > -1.0:
            print(
                f"NOTE: {dataset_name} {label_column} skew ({dataset[label_column].skew()}) is normal."
            )
        else:
            min_value = dataset[label_column].min()
            dataset[label_column] = dataset[label_column].apply(
                lambda x: x + 1.0e-3 - min_value
            )
            transformed, lambda_ = boxcox(dataset[label_column].values)
            new_skew = pd.Series(transformed).skew()
            if new_skew < 1.0 and new_skew > -1.0:
                dataset[label_column] = pd.Series(transformed)
                print(
                    f"NOTE: boxcox [(x^k - 1)/k, k={lambda_}] transform {dataset_name} {label_column} skew ({original_skew}) to ({new_skew})"
                )
            else:
                print(f'NOTE: {dataset_name} {label_column} skew ({dataset[label_column].skew()})')
    dataset = dataset.groupby(smiles_column).agg(
        {label_column:['mean']}
    ).reset_index()
    dataset.columns = ['_'.join(map(str, col)).strip('_') for col in dataset.columns]
    # print(dataset)
    print(f"NOTE: {dataset_name} dataset size after groupby ({len(dataset)})")
    dataset = dataset[[smiles_column, f'{label_column}_mean']]
    dataset.columns = ['SMILES', 'Label']
    lower = dataset['Label'].quantile(0.02)
    upper = dataset['Label'].quantile(0.98)
    dataset['Label'] = (
        dataset['Label']
        .clip(lower=lower, upper=upper)
        .sub(lower)
        .div(upper - lower)
    )
    print(f'NOTE: {dataset_name} dataset preprocessing finished.')
    print(dataset)
    dataset = dataset.reset_index(drop=True)
    return dataset

def cluster(
    dataset,
    dataset_name,
    smiles_column,
    mini_cluster_number = 30,
    expected_cluster_number = 50,
):
    cluster_labels = []
    skeleton_labels = dataset[smiles_column].apply(lambda x:get_skeleton(x))
    if len(set(skeleton_labels)) > mini_cluster_number:
        dataset['Skeleton'] = skeleton_labels
        cluster_labels.append('Skeleton')
        except_cluster_index = 2
    else:
        except_cluster_index = 3
    combinefp = Fingerprint(["ECFP4", "FCFP6", "AtomPairs", "TopologicalTorsion"])
    cluster_index_num = 0
    features = combinefp.extract_features(
        dataset, 
        smiles_column = smiles_column,
        prefix = f'CombineFP_'
    )
    features_array = features.values 
    pca_array = reduce_dimension['PCA'](
        features_array, 
        16, 
        1207 # random seed
    )
    cluster_model = cluster_models['euclidean'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(pca_array)
    euclidean_labels = cluster_model.labels_
    if len(set(euclidean_labels)) > mini_cluster_number:
        dataset['CombineFP_Euclidean'] = pd.Series(euclidean_labels)
        cluster_labels.append('CombineFP_Euclidean')
        cluster_index_num += 1
    cluster_model = cluster_models['MeanShift'](None).fit(pca_array)
    affinity_labels = cluster_model.labels_
    if len(set(affinity_labels)) > mini_cluster_number:
        dataset['CombineFP_MeanShift'] = pd.Series(affinity_labels)
        cluster_labels.append('CombineFP_MeanShift')
        cluster_index_num += 1
    cluster_model = cluster_models['cosine'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(pca_array)
    affinity_labels = cluster_model.labels_
    if len(set(affinity_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['CombineFP_Cosine'] = pd.Series(affinity_labels)
        cluster_labels.append('CombineFP_Cosine')
        cluster_index_num += 1
    cluster_model = cluster_models['DBSCAN'](None).fit(pca_array)
    DBSCAN_labels = cluster_model.labels_
    if len(set(DBSCAN_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['CombineFP_DBSCAN'] = pd.Series(DBSCAN_labels)
        cluster_labels.append('CombineFP_DBSCAN')
        cluster_index_num += 1
    cluster_model = cluster_models['Birch'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(features_array)
    birch_labels = cluster_model.labels_
    if len(set(birch_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['CombineFP_Birch'] = pd.Series(birch_labels)
        cluster_labels.append('CombineFP_Birch')
        cluster_index_num += 1
    ecfp4 = Fingerprint(["ECFP4"])
    features = ecfp4.extract_features(
        dataset, 
        smiles_column = smiles_column,
        prefix = f'ECFP4_'
    )
    cluster_index_num = 0
    features_array = features.values 
    pca_array = reduce_dimension['PCA'](
        features_array, 
        16, 
        1207 # random seed
    )
    cluster_model = cluster_models['euclidean'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(pca_array)
    euclidean_labels = cluster_model.labels_
    if len(set(euclidean_labels)) > mini_cluster_number:
        dataset['ECFP4_Euclidean'] = pd.Series(euclidean_labels)
        cluster_labels.append('ECFP4_Euclidean')
        cluster_index_num += 1
    cluster_model = cluster_models['MeanShift'](None).fit(pca_array)
    affinity_labels = cluster_model.labels_
    if len(set(affinity_labels)) > mini_cluster_number:
        dataset['ECFP4_MeanShift'] = pd.Series(affinity_labels)
        cluster_labels.append('ECFP4_MeanShift')
        cluster_index_num += 1
    cluster_model = cluster_models['cosine'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(pca_array)
    affinity_labels = cluster_model.labels_
    if len(set(affinity_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['ECFP4_Cosine'] = pd.Series(affinity_labels)
        cluster_labels.append('ECFP4_Cosine')
        cluster_index_num += 1
    cluster_model = cluster_models['DBSCAN'](None).fit(pca_array)
    DBSCAN_labels = cluster_model.labels_
    if len(set(DBSCAN_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['ECFP4_DBSCAN'] = pd.Series(DBSCAN_labels)
        cluster_labels.append('ECFP4_DBSCAN')
        cluster_index_num += 1
    cluster_model = cluster_models['Birch'](
        max(expected_cluster_number, int(0.1 * len(dataset)))
    ).fit(features_array)
    birch_labels = cluster_model.labels_
    if len(set(birch_labels)) > mini_cluster_number and cluster_index_num < except_cluster_index:
        dataset['ECFP4_Birch'] = pd.Series(birch_labels)
        cluster_labels.append('ECFP4_Birch')
        cluster_index_num += 1
    for label in cluster_labels:
        print(f"NOTE: {dataset_name} {label} cluster number: {len(set(dataset[label]))}")
    return dataset, cluster_labels

def split(
    dataset,
    dataset_name,
    cluster_labels,
    mini_partition_size = 30,
):
    partition_size = max(mini_partition_size, int(0.1 * len(dataset)))
    dataset['partition'] = 0
    mean_value = dataset['Label'].mean()
    is_classification = (dataset['Label'].nunique() == 2) and (
        set(dataset['Label'].unique()) == {0.0, 1.0}
    )
    threshold = 0.25 if is_classification else 0.1
    # 1. Identify mutually exclusive split samples
    for split_index in [1, 2, 3, 4, 5, 6]: # 12-3, 34-5, 56-1
        split_pass = False
        attempt = 0
        while split_pass == False and attempt < 500:
            attempt += 1
            np.random.seed(random.randint(0, 2025))
            working_df = dataset[dataset['partition']==0].copy()
            candidate_indices = set(working_df.index.tolist())
            split_indices = []
            cluster_maps = {
                label: working_df.groupby(label).groups 
                for label in cluster_labels
            }
            while len(split_indices) < partition_size and candidate_indices:
                selected = random.choice(
                    list(candidate_indices)
                )
                to_remove = set()
                for label in cluster_labels:
                    cluster_id = working_df.at[selected, label]
                    to_remove.update(cluster_maps[label].get(cluster_id, set()))
                if len(to_remove) > partition_size:
                    continue
                candidate_indices -= to_remove
                split_indices += [selected] + list(to_remove)
            split_mean = working_df.loc[split_indices, 'Label'].mean()
            if abs(mean_value - split_mean) <= threshold:
                split_pass = True
        if attempt >= 500:
            raise RuntimeError(
                f"Error: Failed to create partition {split_index} for {dataset_name} after 500 attempts."
            )
        # Create split set flags
        dataset.loc[split_indices, ['partition']] = split_index
    return dataset

def partition(
    dataset,
    dataset_name,
    cluster_labels,
    output_fn,
    mini_val_size = 80,
):
    # partition the dataset
    dataset = split(
        dataset,
        dataset_name = dataset_name,
        cluster_labels = cluster_labels,
        mini_partition_size = mini_val_size,
    )
    stat = dataset.groupby(f'partition')['Label'].describe()
    print(f"NOTE: {dataset_name} partition distribution:")
    print(stat)
    stat.to_csv(
        f'{output_fn}/{dataset_name}_stat.csv'
    )
    dataset['replica_1'] = dataset['partition'].apply(
        lambda x: 'test' if x in [1, 2] else 'valid' if x == 3 else 'train'
    )
    dataset['replica_2'] = dataset['partition'].apply(
        lambda x: 'test' if x in [3, 4] else 'valid' if x == 5 else 'train'
    )
    dataset['replica_3'] = dataset['partition'].apply(
        lambda x: 'test' if x in [5, 6] else 'valid' if x == 1 else 'train'
    )
    dataset.to_csv(
        f'{output_fn}/{dataset_name}_raw.csv',
        index=False, header=True, sep=','
    )
    # plot the distribution
    for replica in ['replica_1', 'replica_2', 'replica_3']:
        try:
            is_classification = (dataset['Label'].nunique() == 2) and (
                set(dataset['Label'].unique()) == {0.0, 1.0}
            )
            if is_classification:
                count_table = dataset.groupby(
                    [replica, 'Label']
                ).size().unstack().fillna(0)
                count_table.columns = ['Negative', 'Positive']
                proportion_table = count_table.div(count_table.sum(axis=1), axis=0)
                proportion_table.plot(
                    kind='bar', stacked=True, color=['#1f77b4', '#ff7f0e'], figsize=(4, 4)
                )
                plt.title('Positive/Negative Proportions')
                plt.ylabel('Proportion')
                plt.xlabel('Data Split')
                plt.xticks(rotation=0)
                plt.legend(title='Label', bbox_to_anchor=(1.05, 1), loc='upper left')
                plt.tight_layout()
                plt.savefig(f'{output_fn}/Proportion/{dataset_name}_{replica}.png')
                plt.close()
            else:
                plt.figure(figsize=(4, 4), dpi=600)
                sns.histplot(
                    data=dataset, x='Label', hue=replica,
                    element='step', stat='density', common_norm=False,
                    palette='husl', alpha=0.6
                )
                plt.title('Label Distribution')
                plt.xlabel('Label Value')
                plt.ylabel('Histogram')
                plt.tight_layout()
                plt.savefig(f'{output_fn}/Histogram/{dataset_name}_{replica}.png')
                plt.close()
                plt.figure(figsize=(4, 4))
                sns.kdeplot(
                    data=dataset, x='Label', hue=replica,
                    fill=True, common_norm=False,
                    palette='husl', alpha=0.6
                )
                plt.title('Label Distribution')
                plt.xlabel('Label Value')
                plt.ylabel('Density')
                plt.tight_layout()
                plt.savefig(f'{output_fn}/Density/{dataset_name}_{replica}.png')
                plt.close()
                plt.figure(figsize=(4, 4), dpi=600)
                sns.boxplot(
                    data=dataset, x=replica, hue=replica, 
                    y='Label', palette='husl', legend=False
                )
                plt.title('Label Distribution')
                plt.xlabel('Data Split')
                plt.ylabel('Label Value')
                plt.tight_layout()
                plt.savefig(f'{output_fn}/BoxPlot/{dataset_name}_{replica}.png')
                plt.close()
        except Exception as e:
            print(f"ERROR: Failed to plot distribution for {dataset_name} {replica}: {e}")
    for cluster_id in cluster_labels:
        del dataset[cluster_id]
    return dataset

def process(
    dataset,
    smiles_column,
    label_column,
    output_path,
    dataset_name,
    mini_cluster_number = 50,
    expected_cluster_number = 70,
    mini_test_size = 50
):
    dataset = prepare(
        dataset,
        dataset_name = dataset_name,
        smiles_column = smiles_column,
        label_column = label_column
    )
    if len(dataset) < 210:
        print(f"NOTE: {dataset_name} dataset is too small ({len(dataset)})")
    else:
        dataset, cluster_labels = cluster(
            dataset,
            dataset_name = dataset_name,
            smiles_column = 'SMILES',
            mini_cluster_number = max(mini_cluster_number, int(0.01 * len(dataset))),
            expected_cluster_number = expected_cluster_number
        )
        os.makedirs(f'{output_path}/plot', exist_ok=True)
        os.makedirs(f'{output_path}/plot/Proportion', exist_ok=True)
        os.makedirs(f'{output_path}/plot/BoxPlot', exist_ok=True)
        os.makedirs(f'{output_path}/plot/Histogram', exist_ok=True)
        os.makedirs(f'{output_path}/plot/Density', exist_ok=True)
        try:
            dataset = partition(
                dataset,
                dataset_name = dataset_name,
                cluster_labels = cluster_labels,
                output_fn = f'{output_path}/plot/',
                mini_val_size = mini_test_size // 2,
            )
            dataset.to_csv(f'{output_path}/{dataset_name}.csv', index=False)
        except RuntimeError as e:
            print(f"ERROR: {e}")

if __name__ == '__main__':
    dataset_path = sys.argv[1]
    output_path = sys.argv[2]
    dataset_name = sys.argv[3]
    if dataset_path.endswith('.csv'):
        data_table = pd.read_csv(dataset_path)
        data_table_columns = data_table.columns
        smiles_column = [
            col for col in data_table_columns if col in smiles_column_names
        ][0]
        label_column = [
            col for col in data_table_columns if col in label_column_names
        ][0]
        dataset = data_table[[smiles_column, label_column]]
        dataset.columns = ['SMILES', 'Label']
    else:
        dataset_list = []
        for subset in os.listdir(f'{dataset_path}/'):
            data_table = pd.read_csv(
                f'{dataset_path}/{subset}'
            )
            data_table_columns = data_table.columns
            smiles_column = [
                col for col in data_table_columns if col in smiles_column_names
            ][0]
            label_column = [
                col for col in data_table_columns if col in label_column_names
            ][0]
            dataset = data_table[[smiles_column, label_column]]
            dataset.columns = ['SMILES', 'Label']
            dataset_list.append(dataset)
        dataset = pd.concat(dataset_list, axis=0)
    process(
        dataset,
        smiles_column = 'SMILES',
        label_column = 'Label',
        output_path = output_path,
        dataset_name = dataset_name
    )