import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import pandas as pd
from advanced_partition import process

smiles_column_names = [
    'SMILES', 'smiles', 'Smiles', 'Drug', 'Compound', 'smiles_standarized',
    'Molecule', 'Molecular_SMILES', 'Molecular SMILES',
]

label_column_names = [
    'pChEMBL', 
    'pChEMBL_Value',
    'pChEMBL Value',
    'Standard_Value',
    'Label',
    'pIC50',
    'Y',
    'label',
    'score',
    'Score',
]

if __name__ == "__main__":
    data_path = sys.argv[1]
    # read in the data
    phenotype_safety = os.listdir(f'{data_path}/Safety')
    pharmacokinetics = os.listdir(f'{data_path}/Pharmacokinetics')
    # filter the data
    for target_id in phenotype_safety:
        dataset_list = []
        for subset in os.listdir(f'{data_path}/Safety/{target_id}'):
            data_table = pd.read_csv(
                f'{data_path}/Safety/{target_id}/{subset}'
            )
            data_table_columns = data_table.columns
            smiles_column = [
                col for col in data_table_columns if col in smiles_column_names
            ][0]
            label_column = [
                col for col in data_table_columns if col in label_column_names
            ][0]
            dataset = data_table[[smiles_column, label_column]]
            dataset.columns = ['SMILES', 'Label']
            dataset_list.append(dataset)
        dataset = pd.concat(dataset_list, axis=0)
        process(
            dataset,
            smiles_column = 'SMILES',
            label_column = 'Label',
            output_path = data_path,
            dataset_name = target_id
        )
    # for target_id in pharmacokinetics:
    #     dataset_list = []
    #     for subset in os.listdir(f'{data_path}/Pharmacokinetics/{target_id}'):
    #         data_table = pd.read_csv(
    #             f'{data_path}/Pharmacokinetics/{target_id}/{subset}'
    #         )
    #         data_table_columns = data_table.columns
    #         smiles_column = [
    #             col for col in data_table_columns if col in smiles_column_names
    #         ][0]
    #         label_column = [
    #             col for col in data_table_columns if col in label_column_names
    #         ][0]
    #         dataset = data_table[[smiles_column, label_column]]
    #         dataset.columns = ['SMILES', 'Label']
    #         dataset_list.append(dataset)
    #     dataset = pd.concat(dataset_list, axis=0)
    #     process(
    #         dataset,
    #         smiles_column = 'SMILES',
    #         label_column = 'Label',
    #         output_path = data_path,
    #         dataset_name = target_id
    #     )





