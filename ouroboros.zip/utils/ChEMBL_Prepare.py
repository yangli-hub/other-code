import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import numpy as np
import pandas as pd
from advanced_partition import (
    process
)

chembl_standard_type = {
    'Binding': ['Kd', 'Ki'],
    'IC50': ['IC50'],
    'EC50': ['EC50'],
    'AC50': ['AC50'],
    'Potency': ['Potency'],
    'Activation': ['Emax'],
    'Inhibition': [
        'Inhibition', 
        'Residual Activity', 
        '% Control', 
        '% Ctrl', 
        'Residual activity', 
        '%Inhib (Mean)',
    ],
}

def process_pchembl(
    target_subset,
):
    nM_dataset = target_subset[target_subset['Standard_Units'] == 'nM']
    nM_dataset['pChEMBL'] = nM_dataset['Standard_Value'].apply(
        lambda x: -np.log10(x * 1e-9)
    )
    uM_dataset = target_subset[target_subset['Standard_Units'] == 'uM']
    uM_dataset['pChEMBL'] = uM_dataset['Standard_Value'].apply(
        lambda x: -np.log10(x * 1e-6)
    )
    pM_dataset = target_subset[target_subset['Standard_Units'] == 'pM']
    pM_dataset['pChEMBL'] = pM_dataset['Standard_Value'].apply(
        lambda x: -np.log10(x * 1e-12)
    )
    sub_dataset = pd.concat([nM_dataset, uM_dataset, pM_dataset], axis=0)
    active_set = sub_dataset[
        sub_dataset['Standard_Relation'].isin(['=', '<', '<=', '~', '<<']) | 
        sub_dataset['Standard_Relation'].isna()
    ]
    inactive_set = sub_dataset[sub_dataset['Standard_Relation'].isin(['>', '>=', '>>'])]
    max_values = inactive_set['pChEMBL'].max()
    inactive_set['pChEMBL'] = inactive_set['pChEMBL'].apply(
        lambda x: x - 4 / max_values
    )
    dataset = pd.concat([active_set, inactive_set], axis=0)
    dataset['pChEMBL'] = dataset['pChEMBL'].apply(lambda x: min(max(4, x), 9))
    return dataset

if __name__ == "__main__":
    chembel_dataset = pd.read_csv(sys.argv[1])
    targets = pd.read_csv(sys.argv[2])
    output_path = sys.argv[3]
    target_chembl_dict = targets.set_index('Target')['ChEMBLID'].to_dict()
    for target_id in target_chembl_dict.keys():
        chembl_id = target_chembl_dict[target_id]
        subset = chembel_dataset[chembel_dataset['Target_ChEMBL_ID'] == chembl_id]
        data_counts = {
            standard_type: len(subset[subset['Standard_Type'].isin(standard_list)])
            for standard_type, standard_list in chembl_standard_type.items()
        }
        data_counts['Inactive'] = len(subset[subset['Comment'].isin([
            'inactive', 'Inactive', 'NA', 'Not Active', 'Inconclusive', 'inconclusive'
        ])])
        print(f"NOTE: data counts: {data_counts} {target_id} ({chembl_id}) ")
        if data_counts['Binding'] >= 600:
            dataset = process_pchembl(subset[subset['Standard_Type'].isin(
                ['Kd', 'Ki']
            )])
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'pChEMBL',
                output_path = output_path,
                dataset_name = f'{target_id}_Binding'
            )
        if all((
            data_counts['IC50'] + data_counts['EC50'] + data_counts['AC50'] >= 600,
            data_counts['Activation'] == 0,
        )):
            dataset = process_pchembl(subset[subset['Standard_Type'].isin(
                ['IC50', 'EC50', 'AC50']
            )])
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'pChEMBL',
                output_path = output_path,
                dataset_name = f'{target_id}_IC50'
            )
        if all((
            data_counts['IC50'] >= 600,
            data_counts['Activation'] > 0,
        )):
            dataset = process_pchembl(subset[subset['Standard_Type'].isin(
                ['IC50']
            )])
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'pChEMBL',
                output_path = output_path,
                dataset_name = f'{target_id}_IC50'
            )
        if all((
            data_counts['AC50'] + data_counts['EC50'] >= 600,
            data_counts['Activation'] > 0,
        )):
            dataset = process_pchembl(subset[subset['Standard_Type'].isin(
                ['AC50', 'EC50']
            )])
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'pChEMBL',
                output_path = output_path,
                dataset_name = f'{target_id}_EC50'
            )
        if all((
            data_counts['Activation'] + data_counts['Inactive'] >= 600,
            data_counts['Activation'] > 100,
        )):
            sub_dataset = subset[subset['Standard_Type'].isin(
                ['Emax']
            )]
            inactive = subset[subset['Comment'].isin(
                ['inactive', 'Inactive', 'Not Active', 'NA', 'Antagonist']
            )]
            inactive['Standard_Value'] = sub_dataset['Standard_Value'].min()
            dataset = pd.concat([sub_dataset, inactive], axis=0)
            dataset['Standard_Value'] = dataset['Standard_Value'].apply(
                lambda x: min(max(0, x), 100)
            )
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'Standard_Value',
                output_path = output_path,
                dataset_name = f'{target_id}_Activation'
            )
        if all((
            data_counts['Binding'] + data_counts['IC50'] + data_counts['EC50'] + data_counts['AC50'] + data_counts['Potency'] >= 100,
        )):
            dose = process_pchembl(subset[subset['Standard_Type'].isin(
                ['IC50', 'EC50', 'AC50', 'Kd', 'Ki']
            )])
            potency = process_pchembl(subset[(subset['Standard_Type'].isin(
                ['Potency']
            )) & (subset['Comment'].isin(['Active', 'active']))])
            action = subset[subset['Standard_Type'].isin(
                ['Inhibition', 'Activity', 'Emax', 'Activation', 'Intrinsic activity']
            )]
            residual = subset[subset['Standard_Type'].isin([
                'Residual Activity', 
                '% Control', 
                '% Ctrl', 
                'Residual activity'
            ])]
            residual['Standard_Value'] = 100 - residual['Standard_Value']
            action_residual = pd.concat([action, residual], axis=0)
            action_residual['Standard_Value'] = action_residual['Standard_Value'].apply(
                lambda x: min(max(0, x), 100)
            )
            action_residual['pChEMBL'] = action_residual['Standard_Value'].apply(
                lambda x: 4.0 + (x/50.0)
            )
            active = subset[subset['Comment'].isin(
                [
                    'Active', 'active', 'Antagonist', 'Agonist'
                ]
            )]
            active['pChEMBL'] = 6.0
            not_active = subset[subset['Comment'].isin(
                [
                    'Not Active', 'NA',
                    'Inconclusive', 'inconclusive', 
                    'inactive', 'Inactive'
                ]
            )]
            not_active['pChEMBL'] = 4.0
            dataset = pd.concat([dose, potency, action_residual, active, not_active], axis=0)
            dataset.drop_duplicates(
                subset=['SMILES'], 
                inplace=True,
                keep='first'
            )
            process(
                dataset,
                smiles_column = 'SMILES',
                label_column = 'pChEMBL',
                output_path = output_path,
                dataset_name = f'{target_id}_Potency'
            )